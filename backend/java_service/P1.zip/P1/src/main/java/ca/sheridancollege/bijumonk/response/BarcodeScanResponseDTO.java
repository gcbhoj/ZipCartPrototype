package ca.sheridancollege.bijumonk.response;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data 
@AllArgsConstructor 
@NoArgsConstructor 
@Builder
public class BarcodeScanResponseDTO {
    private List<String> barcodes;  
    private String message;         
}
