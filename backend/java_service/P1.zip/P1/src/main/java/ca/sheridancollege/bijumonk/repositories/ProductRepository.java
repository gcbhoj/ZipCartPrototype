package ca.sheridancollege.bijumonk.repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import ca.sheridancollege.bijumonk.beans.Product;

public interface ProductRepository extends JpaRepository<Product, Long> {

    Optional<Product> findByBarcode(String barcode);
    Optional<Product> findByProductName(String productName); 


}
