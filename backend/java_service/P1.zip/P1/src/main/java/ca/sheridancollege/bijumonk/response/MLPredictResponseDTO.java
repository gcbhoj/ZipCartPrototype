package ca.sheridancollege.bijumonk.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data 
@AllArgsConstructor 
@NoArgsConstructor 
@Builder
public class MLPredictResponseDTO {
    private String productName;   
    private Double confidence;    
}
