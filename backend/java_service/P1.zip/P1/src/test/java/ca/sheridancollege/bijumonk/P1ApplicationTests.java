package ca.sheridancollege.bijumonk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class P1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
